from flask import render_template, request, redirect, url_for, Blueprint, jsonify, flash, send_file, current_app
from login import mysql
from fpdf import FPDF
from twilio.rest import Client
from datetime import datetime  
import math, tempfile
from werkzeug.security import generate_password_hash

# Inicialización de Blueprints
adduser_bp = Blueprint('adduser', __name__, template_folder='../templates')
add_student_bp = Blueprint('addstudents', __name__, template_folder='../templates')
disable_user_bp = Blueprint('disable_user', __name__, template_folder='../templates')
edit_user_bp = Blueprint('edit_user', __name__, template_folder='../templates')
enable_user_bp = Blueprint('enable', __name__, template_folder='../templates')
listcrud_bp = Blueprint('listcrud', __name__, template_folder='../templates')
listworker_bp = Blueprint('listworker', __name__, template_folder='templates')
disable_bp = Blueprint('disable', __name__, template_folder='templates')
report_bp = Blueprint('report', __name__, template_folder='templates')
ver_usuario_bp = Blueprint('ver_usuario', __name__)
shedule_bp = Blueprint('shedule', __name__, template_folder='../templates')
add_grade_bp = Blueprint('addgrade', __name__, template_folder='../templates')
dashboard_bp = Blueprint('dashboard', __name__, template_folder='../templates')

class UserDatabase:
    def __init__(self, mysql_connection):
        self.mysql = mysql_connection

    def get_cursor(self):
        try:
            return self.mysql.connection.cursor()  # Usando Diccionario
        except Exception as e:
            print(f"Error al obtener el cursor: {e}")
            return None


    def inject_dashboard(self):
        try:
            cursor = self.mysql.connection.cursor()

            # === Totales generales ===
            cursor.execute("SELECT COUNT(*) AS total_excuses FROM pending_excuses")
            total_excuses = cursor.fetchone()["total_excuses"]

            cursor.execute("SELECT COUNT(*) AS total_accepted FROM accepted_excuses")
            total_accepted = cursor.fetchone()["total_accepted"]

            cursor.execute("SELECT COUNT(*) AS total_rejected FROM rejected_excuses")
            total_rejected = cursor.fetchone()["total_rejected"]

            # === Totales desde el lunes ===
            cursor.execute("""
                SELECT COUNT(*) AS week_excuses 
                FROM pending_excuses 
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)
            """)
            week_excuses = cursor.fetchone()["week_excuses"]

            cursor.execute("""
                SELECT COUNT(*) AS week_accepted 
                FROM accepted_excuses 
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)
            """)
            week_accepted = cursor.fetchone()["week_accepted"]

            cursor.execute("""
                SELECT COUNT(*) AS week_rejected 
                FROM rejected_excuses 
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)
            """)
            week_rejected = cursor.fetchone()["week_rejected"]
            
            # Conteo de usuarios por rol
            
            cursor.execute("SELECT COUNT(*) AS total_user FROM users")
            total_user = cursor.fetchone()["total_user"]
                 
            cursor.execute("SELECT COUNT(*) AS total_user FROM userunbailited")
            total_user_userunbailited = cursor.fetchone()["total_user"]
            
            cursor.execute("SELECT COUNT(*) AS total_user FROM students")
            total_students = cursor.fetchone()["total_user"]
 
            cursor.execute("SELECT rol, COUNT(*) AS total FROM users GROUP BY rol")
            roles_data = cursor.fetchall()
            total_admin = total_padre = total_profesor = total_otro = total_administration = 0
            for row in roles_data:
                rol = row["rol"].lower()
                if rol == "admin":
                    total_admin = row["total"]
                elif rol == "parent":
                    total_padre = row["total"]
                elif rol == "teacher":
                    total_profesor = row["total"]
                elif rol == "administration":
                    total_administration = row["total"]
                else:
                    total_otro += row["total"]  # para otros roles desconocidos
            
            #Mensajes
            
            cursor.execute("SELECT COUNT(*) AS menssage FROM contact")
            menssage = cursor.fetchone()["menssage"]
            return {
                    
                    'total_excuses': total_excuses,
                    'total_accepted': total_accepted,
                    'total_rejected': total_rejected,
                    'week_excuses': week_excuses,
                    'week_accepted': week_accepted,
                    'week_rejected': week_rejected,
                    'total_admin': total_admin,
                    'total_padre': total_padre,
                    'total_profesor': total_profesor,
                    'total_administration': total_administration,
                    'total_user': total_user,
                    'total_user_userunbailited': total_user_userunbailited,
                    'total_students': total_students,
                    'total_otro': total_otro,
                    'menssage': menssage
                }
                
        except Exception as e:
            print(f"Error al obtener los totales: {e}")
            return {
                'total_excuses': 0,
                'total_accepted': 0,
                'total_rejected': 0,
                'week_excuses': 0,
                'week_accepted': 0,
                'week_rejected': 0,
                'total_admin': 0,
                'total_padre': 0,
                'total_profesor': 0,
                'total_administration': 0,
                'total_user': 0,
                'total_user_userunbailited': 0,
                'total_otro': 0
            }
        finally:
            cursor.close()


    def insert_user(self, name, rol, phone, idcard, password, profile_pic):
        cursor = self.mysql.connection.cursor()
        # Cifrar la contraseña
        hashed_password = generate_password_hash(password)
        query = """
         INSERT INTO users (name, rol, phone, idcard, password, profile_pic)
         VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (name, rol, phone, idcard, hashed_password, profile_pic))
        self.mysql.connection.commit()
        cursor.close()

    def insert_students(self, name, grade):
        try:
            cursor = self.get_cursor()
            cursor.execute("""
                INSERT INTO students (name, grade) 
                VALUES (%s, %s)
            """, (name, grade))
            self.mysql.connection.commit()
        except Exception as e:
            print(f"Error al insertar usuario: {e}")
            self.mysql.connection.rollback()
        finally:
            if cursor:
                cursor.close()
                
    def insert_grade(self, grade):
        try:
            cursor = self.get_cursor()
            cursor.execute("""
                INSERT INTO grade ( grade) 
                VALUES (%s)
            """, ( grade,))
            self.mysql.connection.commit()
        except Exception as e:
            print(f"Error al insertar usuario: {e}")
            self.mysql.connection.rollback()
        finally:
            if cursor:
                cursor.close()
                
    def update_user(self, user_id, name, rol, phone, idcard, password=None):
        try:
            hashed_password = generate_password_hash(password)
            cursor = self.get_cursor()
            if password:
                cursor.execute('''UPDATE users 
                                  SET name = %s, idcard = %s, phone = %s, rol = %s, password = %s 
                                  WHERE id = %s''',
                               (name, idcard, phone, rol, hashed_password, user_id))
            else:
                cursor.execute('''UPDATE users 
                                  SET name = %s, idcard = %s, phone = %s, rol = %s 
                                  WHERE id = %s''',
                               (name, idcard, phone, rol, user_id))
            self.mysql.connection.commit()
        except Exception as e:
            print(f"Error al actualizar usuario: {e}")
            self.mysql.connection.rollback()
        finally:
            if cursor:
                cursor.close()

    def get_users(self, condition='', params=None, table='users', limit=None, offset=None):
        cursor = None
        try:
            cursor = self.get_cursor()
            if not cursor:
                return []

            sql = f"SELECT * FROM `{table}` {condition}"
            all_params = params.copy() if params else []

            if limit is not None and offset is not None:
                sql += " LIMIT %s OFFSET %s"
                all_params += [limit, offset]

            print(f"Ejecutando consulta: {sql} — params: {all_params}")
            cursor.execute(sql, all_params)
            return cursor.fetchall()
        except Exception as e:
            print(f"Error al obtener usuarios: {e}")
            return []
        finally:
            if cursor:
                cursor.close()
                
        

    def count_users(self, condition='', params=None, table='users'):
        cursor = None
        try:
            cursor = self.get_cursor()
            if not cursor:
                return 0

            sql = f"SELECT COUNT(*) AS total FROM `{table}` {condition}"
            print(f"Ejecutando conteo: {sql} — params: {params}")
            cursor.execute(sql, params or [])
            row = cursor.fetchone()
            return row['total'] if row else 0
        except Exception as e:
            print(f"Error al contar usuarios: {e}")
            return 0
        finally:
            if cursor:
                cursor.close()


                
    def get_disabled_users(self, per_page=7, offset=0):
        try:
            cursor = self.get_cursor()
            query = "SELECT * FROM userunbailited LIMIT %s OFFSET %s"
            cursor.execute(query, (per_page, offset))
            return cursor.fetchall()
        except Exception as e:
            print(f"Error al obtener usuarios deshabilitados: {e}")
            return []
        finally:
            if cursor:
                cursor.close()

    def delete_user(self, user_id, table='users'):
        try:
            cursor = self.get_cursor()
            cursor.execute(f"DELETE FROM {table} WHERE id = %s", (user_id,))
            self.mysql.connection.commit()
        except Exception as e:
            print(f"Error al eliminar usuario: {e}")
            self.mysql.connection.rollback()
        finally:
            if cursor:
                cursor.close()
                
    def delete_message(self, message_id):
        try:
            cursor = self.get_cursor()
            cursor.execute("DELETE FROM contact WHERE id_contact = %s", (message_id,))
            self.mysql.connection.commit()
        except Exception as e:
            print(f"Error al eliminar el mensaje: {e}")
            self.mysql.connection.rollback()
        finally:
            if cursor:
                cursor.close()

class ScheduleDatabase:
    def __init__(self, mysql_connection):
        self.mysql = mysql_connection

    def get_cursor(self):
        try:
            return self.mysql.connection.cursor()
        except Exception as e:
            print(f"Error al obtener cursor: {e}")
            return None

    def insert_schedule(self, teacher_id, day_of_week, grade):
        cursor = self.get_cursor()
        try:
            sql = """
            INSERT INTO teacher_schedule (teacher_id, day_of_week, grade)
            VALUES (%s, %s, %s)
            """
            cursor.execute(sql, (teacher_id, day_of_week, grade))
            self.mysql.connection.commit()
        except Exception as e:
            print(f"Error al insertar horario: {e}")
            self.mysql.connection.rollback()
        finally:
            if cursor:
                cursor.close()

    def get_all_teachers(self):
        cursor = self.get_cursor()
        try:
            sql = "SELECT id, name FROM users WHERE rol = 'teacher'"
            cursor.execute(sql)
            return cursor.fetchall()
        except Exception as e:
            print(f"Error al obtener profesores: {e}")
            return []
        finally:
            if cursor:
                cursor.close()

class UpdateController:
    def __init__(self, mysql):
        self.mysql = mysql

    def register(self, type, detail):
        cursor = self.mysql.connection.cursor()
        query = "INSERT INTO update_notification (type, detail) VALUES (%s, %s)"
        cursor.execute(query, (type, detail))
        self.mysql.connection.commit()
        cursor.close()

@dashboard_bp.route('/dashboard')
def dashboard():
    user_db = UserDatabase(mysql)
    dashboard_data = user_db.inject_dashboard()

    cursor = mysql.connection.cursor()

    # Últimas actualizaciones
    cursor.execute("SELECT * FROM update_notification ORDER BY date DESC LIMIT 4")
    updates = cursor.fetchall()

    # Últimos mensajes
    
    cursor.execute("SELECT * FROM contact ")
    menssages_complet = cursor.fetchall()
    
    cursor.execute("SELECT * FROM contact ORDER BY date DESC LIMIT 3")
    menssages = cursor.fetchall()

    # Total de mensajes
    cursor.execute("SELECT COUNT(*) FROM contact")
    total_menssages = cursor.fetchone()['COUNT(*)']


    cursor.close()

    return render_template(
        'crud/dashboard.html',
        **dashboard_data,
        updates=updates,
        menssages=menssages,
        total_menssages=total_menssages,
        menssages_complet=menssages_complet
    )

@dashboard_bp.route('/chart/excusas')
def chart_excusas():
    cursor = mysql.connection.cursor()

    cursor.execute("SELECT COUNT(*) AS total_excuses FROM pending_excuses")
    total_excuses = cursor.fetchone()["total_excuses"]

    cursor.execute("SELECT COUNT(*) AS total_accepted FROM accepted_excuses")
    total_accepted = cursor.fetchone()["total_accepted"]

    cursor.execute("SELECT COUNT(*) AS total_rejected FROM rejected_excuses")
    total_rejected = cursor.fetchone()["total_rejected"]

    cursor.close()

    return jsonify({
        "labels": ["Pendientes", "Aceptadas", "Rechazadas"],
        "data": [total_excuses, total_accepted, total_rejected]
    })

@dashboard_bp.route('/chart/usuarios')
def chart_usuarios():
    cursor = mysql.connection.cursor()

    cursor.execute("SELECT COUNT(*) AS total_user FROM users")
    total_user = cursor.fetchone()["total_user"]

    cursor.execute("SELECT COUNT(*) AS total_user FROM userunbailited")
    total_user_userunbailited = cursor.fetchone()["total_user"]

    cursor.execute("SELECT COUNT(*) AS total_user FROM students")
    total_students = cursor.fetchone()["total_user"]

    cursor.execute("SELECT rol, COUNT(*) AS total FROM users GROUP BY rol")
    roles_data = cursor.fetchall()

    total_admin = total_padre = total_profesor = total_administration = 0
    for row in roles_data:
        rol = row["rol"].lower()
        if rol == "admin":
            total_admin = row["total"]
        elif rol == "parent":
            total_padre = row["total"]
        elif rol == "teacher":
            total_profesor = row["total"]
        elif rol == "administration":
            total_administration = row["total"]

    cursor.close()

    return jsonify({
        "labels": [
            "Usuarios", 
            "Deshabilitados", 
            "Estudiantes", 
            "Admins", 
            "Padres", 
            "Profesores", 
            "Administración"
        ],
        "data": [
            total_user,
            total_user_userunbailited,
            total_students,
            total_admin,
            total_padre,
            total_profesor,
            total_administration
        ]
    })


@dashboard_bp.route('/solved', methods=['POST'])
def solved():
    message_id = request.form.get('message_id')
    
    if message_id:
        user_db = UserDatabase(mysql)
        user_db.delete_message(message_id)
        mensaje_texto = (
            f"Hola Usuario!\n"
            f"Nos complace informarle que su problema ha sido resuelto.\n"
        )
        send_whatsapp_message('+18498809890', mensaje_texto)

    return redirect(url_for('dashboard.dashboard'))

# Agregar usuario

@adduser_bp.route('/')
def show_form():
    return render_template('crud/adduser.html')

account_sid = "AC0c60b0f4c2b82eda97f8259d47423412"
auth_token  = "6e9ad64fa6d18f9d89a2321751aa47af"
twilio_whatsapp_number = 'whatsapp:+14155238886'

# Inicialización del cliente de Twilio
twilio_client = Client(account_sid, auth_token)


def send_whatsapp_message(to, message):
    """ Envía un mensaje de WhatsApp usando Twilio. """
    try:
        msg = twilio_client.messages.create(
            body=message,
            from_=twilio_whatsapp_number,
            to=f'whatsapp:{to}'
        )
        print(f"✅ Mensaje WhatsApp enviado: SID {msg.sid}")
        return msg.sid
    except Exception as e:
        print(f"❌ Error al enviar WhatsApp: {e}")
        raise


@adduser_bp.route('/adduser', methods=['GET', 'POST'])
def add_user():
    """ Procesa el formulario de alta de usuario y envía notificación por WhatsApp """
    if request.method == 'GET':
        return redirect(url_for('adduser.show_form'))

    try:
        # 1) Recoger datos del formulario
        name       = request.form.get('nameadd')
        rol        = request.form.get('roladd')
        phone      = request.form.get('phoneadd')
        idcard     = request.form.get('idcardaad')
        password   = request.form.get('passwordadd')
        profile_pic = 'ASSETS/IMG/GenericImg/usuario.png'

        # 2) Validación de campos
        if not all([name, rol, phone, idcard, password]):
            return jsonify({"error": "Todos los campos son requeridos"}), 400

        # 3) Insertar en la base de datos
        user_db = UserDatabase(mysql)
        user_db.insert_user(name, rol, phone, idcard, password, profile_pic)
        
        update = UpdateController(mysql)
        update.register('Agregaro', f'Se ha agregado un nuevo usuario ususario {name} rol: {rol}')

        # 4) Componer mensaje y enviar por WhatsApp
        mensaje_texto = (
            f"Hola {name}!\n"
            "Ya puedes ingresar a GESDE y empezar a usar tu cuenta.\n"  
            f"Tu cedula para ingresar es: {idcard}\n"
            f"Tu contraseña es: {password}"
        )
        send_whatsapp_message('+18498809890', mensaje_texto)

        # 5) Redirigir a la lista de usuarios
        return redirect(url_for('listcrud.listuser'))

    except Exception as e:
        # Log y respuesta de error
        print(f"Error en add_user: {e}")
        return jsonify({"error": str(e)}), 500

@add_student_bp.route('/add_students', methods=['GET', 'POST'])
def add_student():
    
    if request.method == 'GET':
        return render_template('crud/add_students.html')  # Redirige al formulario

    if request.method == 'POST':
        try:
            # Obtener datos del formulario
            name = request.form['studentName']
            grade = request.form['grado']
            print(name, grade)
            # Validar que los campos no estén vacíos
            if not all([name, grade]):
                return jsonify({"error": "Todos los campos son requeridos"}), 400

            # Insertar en la base de datos
            user_db = UserDatabase(mysql)
            user_db.insert_students(name, grade)

            update = UpdateController(mysql)
            update.register('Agregaro', f'Se ha un nuevo estudiante {name} grado: {grade}')
            return render_template('crud/add_students.html')

        except Exception as e:
            print({"error": str(e)}), 500

@add_grade_bp.route('/add_grade', methods=['GET', 'POST'])
def add_grade():
    
    if request.method == 'GET':
        return render_template('crud/add_students.html')  # Redirige al formulario

    if request.method == 'POST':
        try:
            # Obtener datos del formulario
            
            grade = request.form['grade']
            # Validar que los campos no estén vacíos
            if not all([ grade]):
                return jsonify({"error": "Todos los campos son requeridos"}), 400

            # Insertar en la base de datos
            user_db = UserDatabase(mysql)
            user_db.insert_grade( grade)
            
            update = UpdateController(mysql)
            update.register('Agregaro', f'Se ha un nuevo grado: {grade}')

            return render_template('crud/add_students.html')

        except Exception as e:
            print({"error": str(e)}), 500

@shedule_bp.route('/add-schedule', methods=['GET', 'POST'])
def save_schedule():
    db = ScheduleDatabase(mysql)

    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        day = request.form['day_of_week']
        grade = request.form['grade']

        db.insert_schedule(teacher_id, day, grade)
        
        update = UpdateController(mysql)
        update.register('Asignado', f'Se ha asignado al profesor {teacher_id} el dia: {day} para el grado: {grade}')
        return redirect(url_for('shedule.save_schedule'))
    


    # GET - Cargar formulario
    teachers = db.get_all_teachers()
    print('Teachers:', teachers)
    return render_template('crud/add_students.html', teachers=teachers)


# Editar usuario
@edit_user_bp.route('/edit_user/<int:user_id>', methods=['GET', 'POST'])
def edit_user(user_id):
    if request.method == 'GET':
        user_db = UserDatabase(mysql)
        usuario = user_db.get_users(table='users', condition=f"WHERE id = {user_id}")

        if not usuario:
            print('Usuario no encontrado.', 'warning')
            flash('Usuario no encontrado.', 'warning')
            return redirect(url_for('listcrud.listuser'))

        print(f"Datos del usuario: {usuario}")  # Para depurar los datos obtenidos
        return render_template('crud/edit_user.html', usuario=usuario[0])  # Pasando solo el primer resultado

    elif request.method == 'POST':
        name = request.form['nameedit']
        idcard = request.form['idcardedit']
        phone = request.form['phoneedit']
        rol = request.form['roledit']
        password = request.form['passwordedit']

        user_db = UserDatabase(mysql)
        user_db.update_user(user_id, name, rol, phone, idcard, password)

        update = UpdateController(mysql)
        update.register('Editado', f'Se ha editado el usuario: {name}')
        flash(f'Usuario {user_id} actualizado con éxito.', 'success')
        return redirect(url_for('listcrud.listuser'))

# Deshabilitar usuario
@disable_user_bp.route('/disable_user/<int:user_id>', methods=['POST'])
def disable_user(user_id):
    try:
        user_db = UserDatabase(mysql)
        usuario = user_db.get_users(f"WHERE id = {user_id}")

        if not usuario:
            flash('Usuario no encontrado.', 'warning')
            return redirect(url_for('listcrud.listuser'))

        # Insertar el usuario en `userunbailited`
        usuario = usuario[0]
        cursor = user_db.get_cursor()
        cursor.execute(
            '''INSERT INTO userunbailited (id, name, rol, phone, idcard, last_updated) 
               VALUES (%s, %s, %s, %s, %s, %s)''', 
            (usuario['id'], usuario['name'], usuario['rol'], usuario['phone'], usuario['idcard'], usuario['last_updated'])
        )

        update = UpdateController(mysql)
        update.register('Deshabilitado', f'Se ha deshabilitado el ususario {usuario['name']}')
        # Eliminar el usuario de `users`
        user_db.delete_user(user_id)

        # Obtener solo los usuarios deshabilitados
        cursor.execute("SELECT * FROM userunbailited")
        disabled_users = cursor.fetchall()

        flash(f'Usuario {user_id} deshabilitado con éxito.', 'success')
        return render_template('crud/disable_user.html', disabled_users=disabled_users)

    except Exception as e:
        flash(f'Error al deshabilitar usuario: {e}', 'danger')

    return render_template('crud/disable_user.html')

# Eliminar usuario definitivamente
@disable_user_bp.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    try:
        user_db = UserDatabase(mysql)
        user_db.delete_user(user_id, table='userunbailited')
        
        update = UpdateController(mysql)
        update.register('Eliminado', f'Se ha eliminado el ususario {user_id}')
        flash(f'Usuario {user_id} eliminado con éxito.', 'success')
    except Exception as e:
        flash(f'Error al eliminar usuario: {e}', 'danger')

    return redirect(url_for('listcrud.listuser'))

# Habilitar usuario
@enable_user_bp.route('/enable/<int:user_idenable>', methods=['POST'])
def enable_user(user_idenable):
    try:
        user_db = UserDatabase(mysql)
        
        # Obtener el usuario de 'userunbailited'
        usuario = user_db.get_users(f"WHERE id = {user_idenable}", table='userunbailited')
        
        if not usuario:
            flash('Usuario no encontrado.', 'warning')
            return redirect(url_for('listcrud.listuser'))

        # Insertar el usuario en la tabla 'users'
        usuario = usuario[0]
        cursor = user_db.get_cursor()
        cursor.execute(
            '''INSERT INTO users (name, rol, phone, idcard, password, last_updated) 
               VALUES (%s, %s, %s, %s, %s, %s)''', 
            (usuario['name'], usuario['rol'], usuario['phone'], usuario['idcard'], "123", usuario['last_updated'])
        )
        
        update = UpdateController(mysql)
        update.register('Habilitado', f'Se ha Habilitado el ususario {usuario['name']}')

        # Eliminar el usuario de 'userunbailited'
        user_db.delete_user(user_idenable, table='userunbailited')

        flash(f'Usuario {user_idenable} habilitado con éxito.', 'success')
    except Exception as e:
        print(f'Error al habilitar usuario: {e}', 'danger')

    return redirect(url_for('listcrud.listuser'))

# Visualizar lista de usuarios
@listcrud_bp.route('', methods=['GET'])
def listuser():
    # 1️⃣ Parámetros de paginación
    page     = request.args.get('page',   1,   type=int)
    per_page = request.args.get('per_page', 7, type=int)
    offset   = (page - 1) * per_page

    # 2️⃣ Parámetro de búsqueda
    search = request.args.get('search', '', type=str).strip()
    
    # 3️⃣ Construimos la condición SQL y los params
    condition = "WHERE rol = 'parent'"
    params    = []
    if search:
        # Buscamos en name, idcard y phone (ajusta columnas según tu esquema)
        condition += " AND (name LIKE %s OR idcard LIKE %s OR phone LIKE %s)"
        term = f"%{search}%"
        params = [term, term, term]

    # 4️⃣ Acceso a datos
    user_db     = UserDatabase(mysql)
    total_users = user_db.count_users(condition=condition, params=params)
    usuarios    = user_db.get_users(condition=condition, params=params, limit=per_page, offset=offset)

    # 5️⃣ Paginación
    total_pages = math.ceil(total_users / per_page)
    has_prev    = page > 1
    has_next    = page < total_pages

    # 6️⃣ Render
    return render_template(
        'crud/listuser.html',
        usuarios=usuarios,
        page=page,
        per_page=per_page,
        total_users=total_users,
        total_pages=total_pages,
        has_prev=has_prev,
        has_next=has_next,
        search=search
    )

# Visualizar lista de trabajadores
@listworker_bp.route('/listworker', methods=['GET'])
def listworker():
    # Parámetros de paginación
    page     = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 7, type=int)
    offset   = (page - 1) * per_page

    # Parámetro de búsqueda
    search = request.args.get('search', '', type=str).strip()

    # Condición y parámetros
    condition = "WHERE rol != 'parent'"  # Solo trabajadores (no padres)
    params = []

    if search:
        condition += " AND (name LIKE %s OR idcard LIKE %s OR phone LIKE %s)"
        term = f"%{search}%"
        params = [term, term, term]

    # Acceso a base de datos
    user_db = UserDatabase(mysql)
    total_users = user_db.count_users(condition=condition, params=params)
    usuarios = user_db.get_users(
        condition=condition,
        params=params,
        limit=per_page,
        offset=offset
    )

    # Cálculo de paginación
    total_pages = max(math.ceil(total_users / per_page), 1)
    has_prev = page > 1
    has_next = page < total_pages

    return render_template(
        'crud/listworkers.html',
        usuarios=usuarios,
        page=page,
        per_page=per_page,
        total_users=total_users,
        total_pages=total_pages,
        has_prev=has_prev,
        has_next=has_next,
        search=search
    )


# Visualizar lista de usuarios deshabilitados
@disable_bp.route('/disable')
def disable():
    page     = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 7, type=int)
    offset   = (page - 1) * per_page
    search   = request.args.get('search', '', type=str).strip()

    condition = None
    params = []
    
    user_db = UserDatabase(mysql)

    total_disabled = user_db.count_users(condition=condition, params=params, table='userunbailited')
    total_pages = max(math.ceil(total_disabled / per_page), 1)
    has_prev = page > 1
    has_next = page < total_pages

    usuarios = user_db.get_disabled_users(per_page=per_page, offset=offset)

    return render_template(
        'crud/disable_user.html',
        usuarios=usuarios,
        page=page,
        per_page=per_page,
        total_disabled=total_disabled,
        total_pages=total_pages,
        has_prev=has_prev,
        has_next=has_next,
        search=search
    )


@ver_usuario_bp.route('/get_user_profile/<int:user_id>')
def get_user_profile(user_id):
    db = UserDatabase(mysql)
    try:
        # Obtener información del usuario
        user_data = db.get_users(f"WHERE id = {user_id}")
        
        if not user_data:
            return jsonify({'error': 'Usuario no encontrado'}), 404
            
        user_data = user_data[0]
        
        # Formatear los datos para la respuesta (sin excusas)
        user_profile = {
            'nombre': user_data['name'],
            'rol': user_data['rol'],
            'id': user_data['id'],
            'cedula': user_data['idcard'],
            'telefono': user_data['phone'],
            'ultima_actividad': user_data['last_updated'].strftime('%d/%m/%Y %H:%M'),
            'estado': 'Activo'
        }
        
        return jsonify(user_profile)
    except Exception as e:
        print(f"Error al obtener perfil de usuario: {e}")
        return jsonify({'error': str(e)}), 500

class PDF(FPDF):
    def __init__(self):
        super().__init__()
        self.set_auto_page_break(auto=True, margin=15)
        self.primary_r, self.primary_g, self.primary_b = 41, 128, 185
        self.secondary_r, self.secondary_g, self.secondary_b = 236, 240, 241
        self.text_r, self.text_g, self.text_b = 52, 73, 94
        self.custom_header = None  # Para saber qué encabezado usar

    def header(self):
        if self.custom_header == 'student':
            self.header_student()
        elif self.custom_header == 'excuse':
            self.header_excuse()
        else:
            # Default header (ejemplo para usuarios generales)
            self.set_fill_color(self.primary_r, self.primary_g, self.primary_b)
            self.rect(0, 0, 210, 25, 'F')
            self.set_font('Arial', 'B', 16)
            self.set_text_color(255, 255, 255)
            self.cell(210, 20, 'REPORTE DE USUARIOS', ln=True, align='C')
            self.set_font('Arial', 'I', 9)
            date_str = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
            self.set_xy(150, 15)
            self.cell(50, 10, f'Generado: {date_str}', 0, 0, 'R')
            self.ln(15)
            self.set_fill_color(self.secondary_r, self.secondary_g, self.secondary_b)
            self.set_text_color(self.text_r, self.text_g, self.text_b)
            self.set_font('Arial', 'B', 10)
            self.set_left_margin(10)
            self.cell(15, 10, 'ID', 1, 0, 'C', 1)
            self.cell(45, 10, 'Nombre', 1, 0, 'C', 1)
            self.cell(25, 10, 'Rol', 1, 0, 'C', 1)
            self.cell(30, 10, 'Teléfono', 1, 0, 'C', 1)
            self.cell(35, 10, 'Cédula', 1, 0, 'C', 1)
            self.cell(40, 10, 'Última Actualización', 1, 1, 'C', 1)

    def header_student(self):
        self.set_fill_color(self.primary_r, self.primary_g, self.primary_b)
        self.rect(0, 0, 210, 25, 'F')
        self.set_font('Arial', 'B', 16)
        self.set_text_color(255, 255, 255)
        self.cell(210, 20, 'REPORTE DE ESTUDIANTES', ln=True, align='C')
        self.set_font('Arial', 'I', 9)
        date_str = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.set_xy(150, 15)
        self.cell(50, 10, f'Generado: {date_str}', 0, 0, 'R')
        self.ln(15)
        self.set_fill_color(self.secondary_r, self.secondary_g, self.secondary_b)
        self.set_text_color(self.text_r, self.text_g, self.text_b)
        self.set_font('Arial', 'B', 10)
        self.set_left_margin(10)
        self.cell(15, 10, 'ID', 1, 0, 'C', 1)
        self.cell(45, 10, 'Nombre', 1, 0, 'C', 1)
        self.cell(25, 10, 'Grado', 1, 1, 'C', 1)
        
    def header_excuse(self):
        self.set_left_margin(5)  # Reducir margen izquierdo
        self.set_right_margin(5)  # (Opcional) Reducir margen derecho
        self.set_fill_color(self.primary_r, self.primary_g, self.primary_b)
        self.rect(0, 0, 210, 25, 'F')
        self.set_font('Arial', 'B', 14)  # Tamaño de fuente del título
        self.set_text_color(255, 255, 255)
        self.cell(200, 20, 'REPORTE DE EXCUSAS', ln=True, align='C')
        self.set_font('Arial', 'I', 8)
        date_str = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.set_xy(150, 15)
        self.cell(50, 10, f'Generado: {date_str}', 0, 0, 'R')
        self.ln(15)

        self.set_fill_color(self.secondary_r, self.secondary_g, self.secondary_b)
        self.set_text_color(self.text_r, self.text_g, self.text_b)
        self.set_font('Arial', 'B', 8)  # Tamaño de fuente reducido
        self.set_left_margin(5)

        # Nueva distribución de columnas: total = 190 mm
        self.cell(15, 8, 'ID', 1, 0, 'C', 1)
        self.cell(35, 8, 'Padre', 1, 0, 'C', 1)
        self.cell(35, 8, 'Estudiante', 1, 0, 'C', 1)
        self.cell(20, 8, 'Grado', 1, 0, 'C', 1)
        self.cell(25, 8, 'Razón', 1, 0, 'C', 1)
        self.cell(25, 8, 'Fecha', 1, 0, 'C', 1)
        self.cell(20, 8, 'Duración', 1, 0, 'C', 1)
        self.cell(15, 8, 'Mensaje', 1, 1, 'C', 1)


    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(self.text_r, self.text_g, self.text_b)
        self.line(10, self.get_y() - 3, 200, self.get_y() - 3)
        self.cell(0, 10, f'Página {self.page_no()} de {{nb}}', 0, 0, 'C')


reportes = Blueprint("reportes", __name__)

class PDFReportGenerator:
    def __init__(self, cursor, sql_query, headers, filename):
        self.cursor = cursor
        self.sql_query = sql_query
        self.headers = headers
        self.filename = filename

    def generate(self):
        self.cursor.execute(self.sql_query)
        data = self.cursor.fetchall()

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", "B", 14)
        pdf.cell(200, 10, txt=self.filename.split(".")[0].replace("_", " ").upper(), ln=True, align="C")
        pdf.ln(10)

        pdf.set_font("Arial", "B", 10)
        for header in self.headers:
            pdf.cell(30, 10, header, 1)
        pdf.ln()

        pdf.set_font("Arial", "", 10)
        for row in data:
            for item in row:
                pdf.cell(30, 10, str(item), 1)
            pdf.ln()

        temp_pdf = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        pdf.output(temp_pdf.name)
        return temp_pdf.name

# Helper para generar reportes
def generar_reporte(mysql, query, headers, filename):
    with mysql.connection.cursor() as cursor:
        generator = PDFReportGenerator(cursor, query, headers, filename)
        path = generator.generate()
        return send_file(path, as_attachment=True)

# Rutas
@reportes.route("/reporte_usuarios")
def reporte_usuarios():
    query = "SELECT nombre, telefono, cedula, rol FROM usuarios"
    headers = ["Nombre", "Teléfono", "Cédula", "Rol"]
    return generar_reporte(reportes.mysql, query, headers, "usuarios.pdf")

@reportes.route("/reporte_usuarios_deshabilitados")
def reporte_usuarios_deshabilitados():
    query = "SELECT nombre, telefono, cedula, rol FROM usuarios WHERE estado = 'inactivo'"
    headers = ["Nombre", "Teléfono", "Cédula", "Rol"]
    return generar_reporte(reportes.mysql, query, headers, "usuarios_deshabilitados.pdf")

@reportes.route("/reporte_trabajadores")
def reporte_trabajadores():
    query = "SELECT nombre, telefono, correo, departamento FROM trabajadores"
    headers = ["Nombre", "Teléfono", "Correo", "Departamento"]
    return generar_reporte(reportes.mysql, query, headers, "trabajadores.pdf")

def truncate_text(text, max_length=15):
    """Recorta el texto si es más largo que el máximo permitido y agrega '...'."""
    if len(text) > max_length:
        return text[:max_length-3] + '...'  # Mantener espacio para los '...'
    return text

@report_bp.route('/report_excuse_pending', methods=['GET'])
def generate_report_pending_excuses():

    from datetime import datetime
    import os

    user_db = UserDatabase(mysql)
    users = [user for user in user_db.get_users(table='pending_excuses')]

    pdf = PDF()
    pdf.custom_header = 'excuse'
    pdf.alias_nb_pages()
    pdf.add_page()

    pdf.set_text_color(70, 70, 70)
    pdf.set_draw_color(189, 195, 199)

    if not users:
        pdf.set_font('Arial', '', 12)
        pdf.cell(0, 10, "No hay excusas registradas.", 0, 1, 'C')
    else:
        pdf.set_font('Arial', '', 8)
        row_height = 8
        row_counter = 0

        for user in users:
            id_excuse = str(user.get('id_excuse', ''))
            parent_name = str(user.get('parent_name', ''))[:35]
            student_name = str(user.get('student_name', ''))[:35]
            grade = str(user.get('grade', ''))[:20]
            reason = str(user.get('reason', ''))[:25]
            excuse_date = str(user.get('excuse_date', ''))

            # Recuperar 'excuse_duration' y 'specification'
            excuse_duration = user.get('excuse_duration', None)  # Si no existe, será None
            message = user.get('specification', None)

            # Depuración: Imprimir en consola para verificar
            print(f"ID Excuse: {id_excuse}, Excuse Duration: {excuse_duration}, Message: {message}")

            # Si no se recuperan los valores correctamente, asignar un valor por defecto
            if excuse_duration is None:
                excuse_duration = 'N/A'
            if message is None:
                message = 'No hay detalles adicionales'

            # Asegurarnos de que los valores sean cadenas
            excuse_duration = str(excuse_duration)
            message = str(message)

            # Truncar el mensaje si es demasiado largo
            message = truncate_text(message, max_length=15)

            # Alternar color de fondo
            if row_counter % 2 == 0:
                pdf.set_fill_color(245, 246, 250)
            else:
                pdf.set_fill_color(255, 255, 255)

            # Dibujar toda la fila de una vez
            pdf.cell(15, row_height, id_excuse, 1, 0, 'C', 1)
            pdf.cell(35, row_height, parent_name, 1, 0, 'L', 1)
            pdf.cell(35, row_height, student_name, 1, 0, 'L', 1)
            pdf.cell(20, row_height, grade, 1, 0, 'C', 1)
            pdf.cell(25, row_height, reason, 1, 0, 'L', 1)
            pdf.cell(25, row_height, excuse_date, 1, 0, 'C', 1)
            pdf.cell(20, row_height, excuse_duration, 1, 0, 'C', 1)
            pdf.cell(15, row_height, message, 1, 1, 'L', 1)  # Mostrar mensaje de especificación truncado

            row_counter += 1

    # Resumen del reporte
    if users:
        pdf.ln(10)
        pdf.set_font('Arial', 'B', 11)
        pdf.set_text_color(pdf.primary_r, pdf.primary_g, pdf.primary_b)
        pdf.cell(0, 10, 'Resumen del Reporte', 0, 1, 'L')

        pdf.set_font('Arial', '', 10)
        pdf.set_text_color(pdf.text_r, pdf.text_g, pdf.text_b)
        pdf.cell(0, 8, f'Total de excusas: {len(users)}', 0, 1, 'L')

        grades = {}
        for user in users:
            grade = str(user.get('grade', 'Sin grado'))
            grades[grade] = grades.get(grade, 0) + 1

        pdf.cell(0, 8, 'Distribución por grado:', 0, 1, 'L')
        for grade, cantidad in grades.items():
            pdf.cell(20, 8, '', 0, 0)
            pdf.cell(0, 8, f'- {grade}: {cantidad} estudiantes', 0, 1, 'L')

    pdf_path = os.path.join(os.getcwd(), "usuarios_reporte.pdf")
    pdf.output(pdf_path)

    return send_file(pdf_path, as_attachment=True, download_name='Reporte_excusas-aceptadas.pdf')


def generate_excuse_report(table_name, filename, report_title):
    from datetime import datetime
    import os

    user_db = UserDatabase(mysql)
    users = user_db.get_users(table=table_name)

    pdf = PDF()
    pdf.custom_header = 'excuse'
    pdf.alias_nb_pages()
    pdf.add_page()

    pdf.set_text_color(70, 70, 70)
    pdf.set_draw_color(189, 195, 199)

    if not users:
        pdf.set_font('Arial', '', 12)
        pdf.cell(0, 10, "No hay excusas registradas.", 0, 1, 'C')
    else:
        pdf.set_font('Arial', '', 8)
        row_height = 8

        for i, user in enumerate(users):
            id_excuse = str(user.get('id_excuse', ''))
            parent_name = str(user.get('parent_name', ''))[:35]
            student_name = str(user.get('student_name', ''))[:35]
            grade = str(user.get('grade', ''))[:20]
            reason = str(user.get('reason', ''))[:25]
            excuse_date = str(user.get('excuse_date', ''))
            excuse_duration = str(user.get('excuse_duration', 'N/A'))
            message = truncate_text(str(user.get('specification', 'No hay detalles adicionales')), 15)

            # Alternar color de fondo
            fill_color = (245, 246, 250) if i % 2 == 0 else (255, 255, 255)
            pdf.set_fill_color(*fill_color)

            pdf.cell(15, row_height, id_excuse, 1, 0, 'C', 1)
            pdf.cell(35, row_height, parent_name, 1, 0, 'L', 1)
            pdf.cell(35, row_height, student_name, 1, 0, 'L', 1)
            pdf.cell(20, row_height, grade, 1, 0, 'C', 1)
            pdf.cell(25, row_height, reason, 1, 0, 'L', 1)
            pdf.cell(25, row_height, excuse_date, 1, 0, 'C', 1)
            pdf.cell(20, row_height, excuse_duration, 1, 0, 'C', 1)
            pdf.cell(15, row_height, message, 1, 1, 'L', 1)

        # Resumen del reporte
        pdf.ln(10)
        pdf.set_font('Arial', 'B', 11)
        pdf.set_text_color(pdf.primary_r, pdf.primary_g, pdf.primary_b)
        pdf.cell(0, 10, 'Resumen del Reporte', 0, 1, 'L')

        pdf.set_font('Arial', '', 10)
        pdf.set_text_color(pdf.text_r, pdf.text_g, pdf.text_b)
        pdf.cell(0, 8, f'Total de excusas: {len(users)}', 0, 1, 'L')

        grades = {}
        for user in users:
            grade = str(user.get('grade', 'Sin grado'))
            grades[grade] = grades.get(grade, 0) + 1

        pdf.cell(0, 8, 'Distribución por grado:', 0, 1, 'L')
        for grade, cantidad in grades.items():
            pdf.cell(20, 8, '', 0, 0)
            pdf.cell(0, 8, f'- {grade}: {cantidad} estudiantes', 0, 1, 'L')

    pdf_path = os.path.join(os.getcwd(), filename)
    pdf.output(pdf_path)
    return send_file(pdf_path, as_attachment=True, download_name=filename)

@report_bp.route('/report_excuse_accepted', methods=['GET'])
def report_excuse_accepted():
    return generate_excuse_report(
        table_name='accepted_excuses',
        filename='Reporte_excusas-aceptadas.pdf',
        report_title='Excusas Aceptadas'
    )

@report_bp.route('/report_excuse_pending', methods=['GET'])
def report_excuse_pending():
    return generate_excuse_report(
        table_name='pending_excuses',
        filename='Reporte_excusas-pendientes.pdf',
        report_title='Excusas Pendientes'
    )

@report_bp.route('/report_excuse_rejected', methods=['GET'])
def report_excuse_rejected():
    return generate_excuse_report(
        table_name='rejected_excuses',
        filename='Reporte_excusas-rechazadas.pdf',
        report_title='Excusas Rechazadas'
    )
